create view total as
select `school`.`student`.`id`                                                                     AS `id`,
       `school`.`student`.`name`                                                                   AS `name`,
       `school`.`student`.`Class`                                                                  AS `Class`,
       ((`school`.`student`.`Chinese` + `school`.`student`.`Math`) + `school`.`student`.`English`) AS `scores`
from `school`.`student`
order by ((`school`.`student`.`Chinese` + `school`.`student`.`Math`) + `school`.`student`.`English`) desc;

