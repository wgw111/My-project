create definer = root@localhost trigger nothing
    before insert
    on student
    for each row
    set new.`name` = 'wang';

