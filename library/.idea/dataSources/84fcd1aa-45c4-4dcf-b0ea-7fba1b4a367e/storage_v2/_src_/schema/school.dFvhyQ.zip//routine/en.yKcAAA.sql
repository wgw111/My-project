create
    definer = root@localhost procedure en(OUT o int)
begin
	
	declare `english` cursor
	for
	select `English` from `student`;
	
	
	open `english`;
	repeat
		fetch `english` into o;
	until o=120 end repeat;
	
	close `english`;
end;

