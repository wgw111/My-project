create
    definer = root@localhost procedure E(IN ID int, OUT o int)
begin
	select `English` from `student` where `id`=`ID` into o;
end;

