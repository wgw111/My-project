create
    definer = root@localhost procedure IsExcellent(IN class int, OUT res tinyint(1))
BEGIN
	DECLARE total INT(5);
	DECLARE num INT(5);
	
	SELECT COUNT(*)  FROM `student` WHERE `Class`=class INTO `total`;
	
	SELECT SUM(`Chinese`+`Math`+`English`)
	FROM `student`
	WHERE `Class`=class
	INTO `total`;
	
	IF (total/num)>90
	THEN
		SET res = 1;
	END IF;
END;

